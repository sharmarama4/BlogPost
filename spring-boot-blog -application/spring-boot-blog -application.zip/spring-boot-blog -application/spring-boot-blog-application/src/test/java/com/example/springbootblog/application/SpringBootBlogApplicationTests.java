package com.example.springbootblog.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
